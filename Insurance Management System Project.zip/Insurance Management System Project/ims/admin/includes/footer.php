  <div class="az-footer">
        <div class="container-fluid">
          <span>&copy; 2018 Insurance Management System (IMS)</span>
         
        </div><!-- container -->
      </div>