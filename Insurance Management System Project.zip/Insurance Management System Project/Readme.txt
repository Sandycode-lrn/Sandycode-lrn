How to run Insurance Management System Project
1. Download the  zip file
2. Extract the file and copy ims folder
3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name imsdb
6. Import imsdb.sql file(given inside the zip package in sql file folder)
7.Run the script http://localhost/ims   (frontend)
8. For admin panel http://localhost/ims/admin  (admin panel)
Credential for admin panel :
username : admin 
Password : Test @123
Credential for user panel :
username : testuser@gmail.com
Password : Test @123
